## Colorizr
Colorizr is a gem that colorize strings. There are 9 colors that you can use. By writing String.colors you'll get array with all available colors. 

#Methods with examples

Most important method is method that colorize strings. To use it you have to type your string (or name of variable) add dot and type color your want.
`"I'm green".green`
`"I'm a blue liar".red`

To get availabe color type
`String.colors`

For colors samples use

`String.sample_colors`

#Instalation

gem install colorizr-0.0.2.gem

You have to also require it in your aplication

`require 'colorizr'`