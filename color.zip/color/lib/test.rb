require 'colorizr'

p String.colors
String.sample_colors

puts "John".red
puts "Paul".green
puts "George".blue
puts "Ringo".yellow