String.instance_eval do
	def colors
		colors = [:red, :green, :yellow, :blue, :pink, :light_blue, :white, :light_grey, :black]
	end
	def colors_ids
		colors_ids = [31,32,33,34,35,94,97,37,30]
	end
	def sample_colors
		colors.each_with_index do |color, i|
			puts "This is \e[#{colors_ids[i]}m#{color}.\e[0m"
		end
	end
end
class String
	def self.create_colors
		String.colors.each_with_index do |color, i|
			define_method(color) do 
				"\e[#{String.colors_ids[i]}m#{self}\e[0m"
			end
		end
	end
end
String.create_colors
